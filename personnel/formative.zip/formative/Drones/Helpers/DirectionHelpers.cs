﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drones
{
    public static class DirectionHelpers
    {
        public static Wind.Directions SelectDirection()
        {
            Random random = new Random();

            int directionIndex = random.Next(1, 5);
            
            switch(directionIndex)
            {
                case 1: 
                    return Wind.Directions.EAST;

                case 2:
                    return Wind.Directions.WEST;

                case 3:
                    return Wind.Directions.NORTH;

                case 4:
                    return Wind.Directions.SOUTH;
            }

            return Wind.Directions.SOUTH;
        }
    }
}
